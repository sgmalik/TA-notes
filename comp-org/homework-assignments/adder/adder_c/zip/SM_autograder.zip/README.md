This is the stuff you zip and upload to Gradescope.
Don't zip the zip directory, just zip the stuff in the zip directory.
To run locally, use autograde_local.sh one directory level up.
For that you will also need to modify run_autograder_local.sh in the same directory.
You will need to modify gradescope/zip/setup.sh, otherwise the autograder won't find submission
